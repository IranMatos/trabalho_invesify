import {Container} from "inversify";
import {TYPES} from "./types";
import {ILogger, IMailer} from "./dominio(REGRAS)/interfaces";
import { WinstonLogger } from "./infra (FERRAMENTAS)/winston.logger";
import { ReportServico } from "./dominio(REGRAS)/report.servico";
import { ServicoNodemailer } from "./infra (FERRAMENTAS)/nodemailer.servico";

const container = new Container();

//Usando o binding. Quando o Logger for requerido, envia o WinstonLogger em modo Singleton
container.bind<ILogger>(TYPES.Logger).to(WinstonLogger).inSingletonScope();
container.bind<IMailer>(TYPES.Mailer).to(ServicoNodemailer).inSingletonScope();
container.bind<ReportServico>(TYPES.ReportService).to(ReportServico);

export{container};