export interface ILogger {
    info(msg: string): void;
    warn(msg: string): void;
    error(msg: string): void;
}

export interface IMailer {
    send(to: string, subject: string, body: string): Promise<void>;
}