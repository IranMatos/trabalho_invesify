export class TamanhoInvalidoRegistro extends Error {
    constructor(){
        super("O registro deve conter entre 1 e 10 numeros.");
        this.name = "TamanhoInvalidoRegistro"
    }
}