export const TYPES = {
    Logger: Symbol.for("Logger"),
    Mailer: Symbol.for("Mailer"),
    ReportService: Symbol.for("ReportService")
};